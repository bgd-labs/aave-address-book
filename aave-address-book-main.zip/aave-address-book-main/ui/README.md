# AAVE Adress Book UI

This is the UI for the AAVE Address Book. It is a simple web application that allows users to search for addresses and view their details.

## Getting Started

First, run the development server:

```bash
npm run dev
# or
yarn dev
# or
pnpm dev
# or
bun dev
```

Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.
